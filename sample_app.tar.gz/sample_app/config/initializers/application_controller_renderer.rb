# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '67b49f088b414712448f0b814eaad1a03780ac5facb0f4e5a5f9c1864cc441f9734c6e9501472c4e30d8f67e35365a5dedf4e5bebc827b382fcee4c292ef34a1'